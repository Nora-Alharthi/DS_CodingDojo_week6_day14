###### I attached my data so you can see what are the thing I did wrong ######



library(shiny)
library(ggplot2)
library(dplyr)

data <- read.csv("coffee_shop.csv")

ui <- fluidPage(
  titlePanel("Riyadh Cofee Shops"),
  sidebarLayout(
    sidebarPanel(
      radioButtons("typeInput", " Type",
                  choices = c("Cafe", "Cofee Shop"),
                  selected = "Cafe"),
      
      selectInput("PlotColor", "Please Select Plot Color",
                  choices = c("blue", "green", "red")),
      
    ),
    mainPanel(
      plotOutput("thePlot"),
    
    )
  )
)

server <- function(input, output) {
  output$typeInput <- renderUI({
    selectInput("typeInput", "Type",
               sort(unique(data$shop_type)),
               selected = "cafee")
 })  
  
  
  
  output$thePlot <- renderPlot({
   
    ggplot(data = data) + 
      geom_bar(mapping = aes(x = rating  , colour = shop_type))
  })
  
}

shinyApp(ui = ui, server = server)